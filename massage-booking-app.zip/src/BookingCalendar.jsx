import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectTrigger, SelectContent, SelectItem } from "@/components/ui/select";

export default function BookingCalendar() {
  const [date, setDate] = useState(null);
  const [time, setTime] = useState("");
  const [duration, setDuration] = useState("");
  const [price, setPrice] = useState(null);

  const baseRates = {
    "30": 99,
    "60": 139,
    "90": 199,
    "120": 255,
    "150": 299,
  };

  const afterHoursRates = {
    "17": [114, 154, 214, 270, 314],
    "18": [129, 169, 229, 285, 329],
    "19": [144, 184, 244, 300, 344],
    "20": [159, 199, 259, 315, 359],
    "21": [179, 219, 279, 335, 379],
    "22": [199, 239, 299, 355, 399],
    "23": [219, 259, 319, 375, 419],
    "24": [239, 279, 339, 395, 439],
  };

  const calculatePrice = () => {
    if (!date || !time || !duration) return;
    const weekday = new Date(date).getDay();
    const hour = parseInt(time.split(":")[0]);
    const finishHour = Math.ceil(hour + parseInt(duration) / 60);

    let base = 0;
    if (hour >= 17) {
      const rateArray = afterHoursRates[finishHour];
      if (rateArray) base = rateArray[parseInt(duration) / 30 - 1];
    } else {
      base = baseRates[duration];
    }

    if (weekday === 6) base *= 1.15;
    else if (weekday === 0) base *= 1.2;

    setPrice(base.toFixed(2));
  };

  return (
    <div className="max-w-md mx-auto mt-10 space-y-4">
      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Book Your Massage</h2>

          <Calendar selected={date} onSelect={setDate} />

          <Select onValueChange={setTime}>
            <SelectTrigger>{time || "Select Time"}</SelectTrigger>
            <SelectContent>
              {[...Array(15)].map((_, i) => {
                const hour = 10 + i;
                return (
                  <SelectItem key={hour} value={`${hour}:00`}>
                    {hour}:00
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>

          <Select onValueChange={setDuration}>
            <SelectTrigger>{duration || "Select Duration"}</SelectTrigger>
            <SelectContent>
              <SelectItem value="30">30 min</SelectItem>
              <SelectItem value="60">60 min</SelectItem>
              <SelectItem value="90">90 min</SelectItem>
              <SelectItem value="120">120 min</SelectItem>
              <SelectItem value="150">150 min</SelectItem>
            </SelectContent>
          </Select>

          <Button onClick={calculatePrice}>Get Price</Button>

          {price && <div className="text-lg font-bold">Price: ${price}</div>}
        </CardContent>
      </Card>
    </div>
  );
}